// This file needs to sit in the Resources directory so that when
// it is used as a URL to a window, the include structure doesn't change.
Titanium.include('qunit/titanium_adaptor.js');