var win = Titanium.UI.createWindow({
  url:'runner.js',
  title: 'Unit Test'
});
win.open();