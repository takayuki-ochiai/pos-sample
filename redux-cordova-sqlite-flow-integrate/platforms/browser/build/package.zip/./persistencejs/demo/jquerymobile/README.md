To try this demo, you need to run it through a web server.
`index.html` uses relative links to persistence.js (in
`../../lib/persistence.js` to be exact), so this path needs to be
available.

Example images, design and text used in the demo are copy-pasted
straight from jquerymobile documentation.
